import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text } from "react-native";
import Appstack from "../navigation/AppStack";
import LoginScreen from "../screens/LoginScreen";
import CustomDrawer from "../components/CustomDrawer";

const Stack = createNativeStackNavigator();

const AuthStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Home" component={Appstack} />
      <Stack.Screen name="Sidebar" component={CustomDrawer} />
    </Stack.Navigator>
  );
};

export default AuthStack;
