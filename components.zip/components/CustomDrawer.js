import {
  View,
  Text,
  ImageBackground,
  Image,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import React from "react";
import {
  DrawerContentScrollView,
  DrawerItemList,
} from "@react-navigation/drawer";

import { Icon } from "react-native-vector-icons/Ionicons";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import { Ionicons } from "@expo/vector-icons";
import { auth } from "../firebase";
import { useNavigation } from "@react-navigation/core";

const CustomDrawer = (props) => {
  return (
    <View style={{ flex: 1 }}>
      <DrawerContentScrollView
        {...props}
        contentContainerStyle={{ backgroundColor: "#4FD471" }}
      >
        <ImageBackground
          source={require("../assets/backgroundprofile2.jpg")}
          style={styles.BackgroundProfile}
        >
          <Image
            source={require("../assets/profilepic.jpg")}
            style={styles.Picprofile}
          />
          <Text style={styles.Text1}>Bem-Vindo</Text>
          <View style={{ flexDirection: "row" }}>
            <Text style={styles.Text2}>John Doe</Text>
          </View>
        </ImageBackground>
        <View style={styles.Viewlist}>
          <DrawerItemList {...props} />
        </View>
      </DrawerContentScrollView>
      <View style={styles.Viewsocial}>
        <TouchableOpacity onPress={() => {}} style={styles.TouchableOpacity}>
          <View style={styles.Viewlast}>
            <Ionicons name="share-social-outline" size={22} />
            <Text style={styles.text}>Partilha com um amigo</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CustomDrawer;

const styles = StyleSheet.create({
  text: {
    fontSize: 15,
    fontFamily: "Roboto-Medium",
    marginLeft: 5,
  },
  Viewlast: {
    flexDirection: "row",
    alignItems: "center",
  },
  TouchableOpacity: {
    paddingVertical: 15,
  },
  Viewsocial: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: "#ccc",
  },
  Viewlist: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 10,
  },
  Text1: {
    color: "#fff",
    fontSize: 18,
    fontFamily: "Roboto-Medium",
    marginBottom: 5,
  },
  Text2: {
    color: "#fff",
    fontSize: 18,
    fontFamily: "Roboto-Regular",
  },
  Picprofile: {
    height: 80,
    width: 80,
    borderRadius: 40,
    marginBottom: 10,
  },
  BackgroundProfile: {
    padding: 20,
    marginTop: 0,
  },
});
